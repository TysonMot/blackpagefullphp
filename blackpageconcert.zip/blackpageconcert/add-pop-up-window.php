<?php 
require("php/function-users-advert.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Black Page SA</title>
<!--attachments-->
<link rel="stylesheet" type="text/css" href="css/layout.css"/>
<link rel="stylesheet" type="text/css" href="css/client-layout.css"/>
<link rel="stylesheet" type="text/css" href="css/client-layout.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive-styles.css"/>
<link rel="shortcut icon" type="image/ico" href="logos/favicon.ico" />
<!--endattachments-->
  <link rel="stylesheet" href="css/colorbox.css" type="text/css" />
<!-- java colorbox -->
</head>
<body class="body">
 <div class="outer-heading">
 <nav class="nav-bar">
<ul>
<li><a href="index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php">Profile</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>

<?php
$usersAdvertData = getAdvertData($_GET['id']);
?>

</div>
<!-- hidden div-->
<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="php/login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
<!-- close hidden-->
<div class="banner-advert-client">
<div class="cover-background">
<div class="image-ad">
<?php echo "<img src='images/".$usersAdvertData['profile_image']."'>";?>
</div>
<div class="business-name-big-bust">
<h1><?php echo $usersAdvertData['name_busi'];?></h1>
</div>
</div>
</div>
<div class="outer-container-advert">

<div class="inner-container-advert">
<div class="qoute-head">
<div class="form-quote-class">
<form class="form-quote" action="php/get-quot.php" method="POST">
<h1>Get a quote</h1>
<p class="quota-text">Fill in the form below and a <?php echo $usersAdvertData['name_busi'];?> Consultant will contact you shortly.</p>
<input type="text" placeholder="Name" name="quote-name" required></input>
<input type="text" placeholder="Email" name="quote-name-email" required></input>
<input type="hidden" placeholder="Email" value =<?php echo $usersAdvertData['email_busi'];?> name="quote-name-email-hidden" required></input>
<input type="hidden" placeholder="Email" value=<?php echo $usersAdvertData['email'];?> name="email" required></input>
<select name="quote-select" required>
<option value"">Select Service</option>
<option value""><?php echo $usersAdvertData['service_status1'];?></option>
<option value""><?php echo $usersAdvertData['service_status2'];?></option>
<option value""><?php echo $usersAdvertData['service_status3'];?></option>
</select>
<input type="submit" value="Get A Quote" name="Quote-form"></input>
</form>
</div>
<div class="right-text-form">
<p>For quicker response, please make use of our quotation form on the left side. Our trained <?php echo $usersAdvertData['name_busi'];?> consultant will contact you shortly. Thanking you</p>
</div>

</div>
</div>
<div class="core-conatiner-advert-part">
<div class="core-conatiner-advert">
<h1>About Us</h1>
<h3>Welcome</h3>
<p class="welcome-descrip"><?php echo $usersAdvertData['busi_descrip'];?></p>
<hr class="line-two">
<h3>Our contact</h3>
<p class="contact-prag-de">Current status : <?php echo $usersAdvertData['busi_online_status'];?></p>
<p class="contact-prag-de">Address : <?php echo $usersAdvertData['busi_address'];?></p>
<p class="contact-prag-de">Province : <?php echo $usersAdvertData['province'];?></p>
<p class="contact-prag-de">Tel : +27<?php echo $usersAdvertData['busi_phone'];?></p>
<p class="contact-prag-de">Email : <?php echo $usersAdvertData['email_busi'];?></p>
<p class="contact-prag-de-last">Click <a href="#pop-message">here</a> to send us a message</p>
</div>
<div class="core-conatiner-advert">
<h1>Our Services</h1>
<h4><?php echo $usersAdvertData['service_status1'];?></h4>
<p class="serv-p"><?php echo $usersAdvertData['service_d1'];?></p>
<h4><?php echo $usersAdvertData['service_status2'];?></h4>
<p class="serv-p"><?php echo $usersAdvertData['service_d2'];?></p>
<h4><?php echo $usersAdvertData['service_status3'];?></h4>
<p class="serv-p"><?php echo $usersAdvertData['service_d3'];?></p>
<h4>Our prices ranges from:</h4>
<br>
<ul>
    From <li><?php echo "R".$usersAdvertData['item_price']."-00";?></li> TO
    <li><?php echo "R".$usersAdvertData['item_second_price']."-00"?></li>
</ul>

</div>
<div class="core-conatiner-advert">
<h1>Our product</h1>
<a href="#pop-image"><?php echo "<img src='images/".$usersAdvertData['busi_image']."'>";?></a>
</div>
</div>
</div>
<!-- popping images pop pop pop TM Motlhabeng-->
<div class="pop-user-image" id="pop-image">
<div class="outer-pop-image">
<div class="heading-pop-image">
<p class="user-pop-name"><?php echo $usersAdvertData['name_busi'];?></p>
<p class="pop-close-it"><a href="#">X</a></p>
</div>
<div class="inner-pop-image">
 <p class="busi_images"><?php echo "<img src='images/".$usersAdvertData['busi_image']."'>";?></p>
</div>
</div>
</div>
<!-- ending pops-->
<!-- pop up message us-->

<div class="pop-user-image-message" id="pop-message">
<div class="outer-pop-image-message">
<div class="heading-pop-image-message">
<p class="user-pop-name"><?php echo $usersAdvertData['name_busi'];?> <?php echo $usersAdvertData['busi_online_status'];?></p>
<p class="pop-close-it"><a href="#">X</a></p>
</div>
<div class="inner-pop-image-message">
 <form class="messgae-us" action="php/messages.php" method="POST" enctype="multipart/form-data">
<input type="text" name="message-us" placeholder="Name" required></input>
<input type="email" name="message-email-us" placeholder="Email" required></input>
<input type="hidden" name="message-email-us-user" value=<?php echo $usersAdvertData['email_busi'];?> ></input>
<input type="hidden" name="email" value=<?php echo $usersAdvertData['email'];?> ></input>
<textarea row="4" col="5" required name="message-us-text" placeholder="type something"></textarea>
<input type="submit" name="message-submit" value="send"></input>

 </div>
</div>
</div>
</div>

<!-- close messaage pop up-->

<!--footer main -->
<footer class="main-footer">
<div class="main-footer-details">
<div class="foot-details">
<h1>Black Page</h1>
<p class="black-foot">We pledge to work with all kind of business and do our outmost best to promote small businesses, regardless of their business history or experience</p>
<h2>Vision</h2>
<p class="black-float">Our vision is to see our Black Page being recoqnized as one of the best online advertising for all sort of businesses</p>
<h2>Mission</h2>
<p class="black-float">Our mission is to have all Small, Medium and Large business get an opportunity to have their businesses advertisied Online at a small rate per month</p>
</div>
<div class="foot-details">
<h1>Black Page Service</h1>
<img src="logos/Capture.png" alt="Black-page-logo" class="pop-up-logo-footer">
<P class="black-page-foot-serv">The list below outline the Services/Products we offer</p>
<ul>
<li>Business Advertising</li>
<li>Business Promotion</li>
<li>Buy or Sell</li>
<li>Services Business</li>
<li>Merchandising Business</li>
<li>Manufacturing Business</li>
</ul>

</div>
<div class="foot-details">
<h1>Other Services</h1>
<ul>
<li>Website desing</li>
<li>Systems development</li>
<li>Computer repairs</li>
<li>Graphic designs</li>
<li>Computer diagnosis</li>
<li>Office equipment</li>
<li>Networking</li>
<li>CCTV installation</li>
</ul>
<p>Contact person : TM Motlhabeng<br>Email:infor@thecomputerxperts.co.za<br>Cell:0785498402<br>www.thecomputerxperts.co.za</p>
</div>
<div class="foot-details">
<h1>Social Media</h1>
<div class="footer-social-med">
<ul class="social-media">
<a href="#"><li>Facebook Black Page</li></a>
<a href="#"><li>Instagram Black Page</li></a>
<a href="#"><li>Twitter Black Page</li></a>
<a href="#"><li>YouTube Black Page</li></a>
</div>
</div>
</div>
<div class="dveloper-foot">
<h1>Black Page developed by : TM Motlhabeng</h1>
<p>&copy Black Page est 2017</p>
<div>
</footer>
<!-- hidden footer-->
<footer class="hidden-footer-login-hidden">
<img src="logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
<!--ending-->
</body>
</html>