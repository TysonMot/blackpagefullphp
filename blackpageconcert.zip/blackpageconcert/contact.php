<?php
session_start();
?>
<!DOCTYPE HTML>
<HTML>
<head>
<title>Black Page SA</title>
<link rel="stylesheet" type="text/css" href="css/layout.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive-styles.css"/>
<link rel="shortcut icon" type="image/ico" href="logos/favicon.ico" />
</head>
<body class="body">
<heading class="main-heading">

<nav class="nav-bar">
<ul>
<li><a href="index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php">Profile</a>';
     }else {
 echo '<a href="#login">Login</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
<!-- hidden div-->
<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="php/login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
<!-- close hidden-->
<!-- pop up login -->
<div class="pop-me-up-login" id="login">
<div class="login-outer">
<div class="login-heading">
<p class="login-exit"><a href="#">X</a></p>
</div>
<div class="login-form-details">
<form class="login-form" action="php/process.php" method="post">
<h1>Please provide your details</h1>
<input type="email" placeholder="Email" name="email" required autofocus></input>
<input type="password" placeholder="Password" name="password" required></input>
<input type="submit" name="login" value="Login"></input>
<footer class="footer-login">
<p>Click here to <a href="#">retrive</a> password or <a href="#apply">register</a></p>
<p class="login-pra-foot">Black Page is here to promote/advertise your business, allow you to sell or buy products online</p>
</footer>
</form>
</div>
</div>
</div>
<!--apply pop up-->
<div class="pop-me-up" id="apply">
<div class="cover-outer">
<div class="pop-me-up-headings">
<img src="logos/Capture.png" alt="Black-page-logo" class="pop-up-logo">
<p class="pop-me-up-close"><a href="#">X</a></p>
</div>
<div class="cover">

<div class="application-fomr">
<h1>Application for advertising</h1>
<p>Please fill the form below to have your business listed on our Black Page</p>
<form class="black-page-form" action="php/reg.php" method="post" enctype="multipart/form-data">
<div class="form-person-details">
<h1>Person details</h1>
<input type="text" placeholder="Name" name="name" required autofocus></input>
<input type="text" placeholder="Surname" name="surname" required></input>
<input type="email" placeholder="Email" name="email" required></input>
<input type="tel" placeholder="Phone" name="tel" required></input>
<input type="text" placeholder="Address" name="address" required></input>
<input type="hidden" value='default.jpg' name="default"></input>
<select required name="province">
<option value="">Choose Province</option>
                         <option value="Limpopo">Limpopo</option>
                         <option value="Gauteng">Gauteng</option>
                         <option value="North West">North West</option>
                         <option value="Mpumalanga">Mpumalanga</option>
                         <option value="Western Cape">Western Cape</option>
                         <option value="KwaZulu-Natal">KwaZulu Natal</option>
                         <option value="Eastern Cape">Eastrn Cape</option>
                         <option value="Northern Cape">Northern Cape</option>
                         <option value="Free State">Free State</option>
                        
</select>
</div>
<div class="business-details">
<h1>Business details</h1>
<input type="text" placeholder="Name" name="name_busi" required></input>
<input type="email" placeholder="Email" name="email_busi" required></input>
<input type="tel" placeholder="Phone" name="tel_busi" required></input>
<input type="text" placeholder="Address" name="address_busi" required></input>
<select required name="busi_type">
<option value="">Choose business type</option>
                         <option value="Services Business">Services Business</option>
                         <option value="Merchandising Business">Merchandising Business</option>
                         <option value="Manufacturing Business">Manufacturing Business</option>
                         <option value="Hybrid Business">Hybrid Business</option>
                        
</select>
<textarea col="4" row="6" placeholder="Describ your business in short" name="busin_descrip" required></textarea>
</div>
<div class="files">
<h1>Product image</h1>
<input type="file" name="image"></input>
</div>
<div class="terms-of-use">
<p>By clicking send you agree to our Terms and Conditions of Black Page.</p>
</div>
<div class="submit-form">
<input type="submit" value="Send" name="upload"></input>
<input type="reset" value="Clear"></input>
</div>
</form>
</div>
</div>
</div>
</div>
<!--close-->
</heading>
<!-- container-->
<div class="container">
<div class="contact-outer-container">
<div class="contact-container">
<div class="address-contact">
<h1>Our addresses</h1>
<address class="address-cont">
<ul>
<li>Luthuli Phase 1</li>
<li>Seshego</li>
<li>Polokwane</li>
<li>0699</li>
</ul>
<p class="contact-det-emails">Email: info@black-page.co.za<br>
Cell:0786498402<br>For technical support contact : techinical@black-page.co.za</p>
</address>
</div>
<div class="contact-form">
<h1>Our contact form</h1>
<form class="form-form-contact" action="php/contact.php" method="POST" enctype="multipart/form-data">
<h2>Fill out our friendly contact form below</h2>
<input type="text" placeholder="Name" name="name"required autofocus></input>
<input type="text" placeholder="Surname" name="surname" required></input>
<input type="email" placeholder="Email" name="email"required></input>
<input type="tel" placeholder="Tel" name="tel" required></input>
<select name="province"required>
<option value="">Choose Province</option>
                         <option value="Limpopo">Limpopo</option>
                         <option value="Gauteng">Gauteng</option>
                         <option value="North West">North West</option>
                         <option value="Mpumalanga">Mpumalanga</option>
                         <option value="Western Cape">Western Cape</option>
                         <option value="KwaZulu Natal">KwaZulu Natal</option>
                         <option value="Eastern Cape">Eastern Cape</option>
                         <option value="Northern Cape">Northern Cape</option>
                         <option value="Free State">Free State</option>
</select>
<select name="type-enqury" required>
<option value="">Type of enquiry</option>
                         <option value="Service Business">Services Business</option>
                         <option value="Merchandising Business">Merchandising Business</option>
                         <option value="Manufacturing Business">Manufacturing Business</option>
                         <option value="Hybrid Business">Hybrid Business</option>                   
</select>
<textarea row="4" col="5" name="message" placeholder="Your Message"></textarea>
<input type="submit" value="Send" name="send-contact></input>
<input type="reset" value="Clear"></input>
</form>
</div>
</div>
</div>
</div>
<div class="map-contact">
<h1>Find us on map</h1>
<iframe class="fram-map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d233432.10595989312!2d29.311020571479798!3d-23.911712944209423!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1ec6d8401183307b%3A0xa720ddd4b18e4df7!2sPolokwane!5e0!3m2!1sen!2sza!4v1487615978357" width="600" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<!--footer main -->
<footer class="main-footer">
<div class="main-footer-details">
<div class="foot-details">
<h1>Black Page</h1>
<p class="black-foot">We pledge to work with all kind of business and do our outmost best to promote small businesses, regardless of their business history or experience</p>
<h2>Vision</h2>
<p class="black-float">Our vision is to see our Black Page being recoqnized as one of the best online advertising for all sort of businesses</p>
<h2>Mission</h2>
<p class="black-float">Our mission is to have all Small, Medium and Large business get an opportunity to have their businesses advertisied Online at a small rate per month</p>
</div>
<div class="foot-details">
<h1>Black Page Service</h1>
<img src="logos/Capture.png" alt="Black-page-logo" class="pop-up-logo-footer">
<P class="black-page-foot-serv">The list below outline the Services/Products we offer</p>
<ul>
<li>Business Advertising</li>
<li>Business Promotion</li>
<li>Buy or Sell</li>
<li>Services Business</li>
<li>Merchandising Business</li>
<li>Manufacturing Business</li>
</ul>
<p class="black-page-foot-derv">Click <a href="#apply">here</a> to have your business listed on our page</p>
</div>
<div class="foot-details">
<h1>Other Services</h1>
<ul>
<li>Website desing</li>
<li>Systems development</li>
<li>Computer repairs</li>
<li>Graphic designs</li>
<li>Computer diagnosis</li>
<li>Office equipment</li>
<li>Networking</li>
<li>CCTV installation</li>
</ul>
<p>Contact person : TM Motlhabeng<br>Email:infor@thecomputerxperts.co.za<br>Cell:0785498402<br>www.thecomputerxperts.co.za</p>
</div>
<div class="foot-details">
<h1>Social Media</h1>
<div class="footer-social-med">
<ul class="social-media">
<a href="#"><li>Facebook Black Page</li></a>
<a href="#"><li>Instagram Black Page</li></a>
<a href="#"><li>Twitter Black Page</li></a>
<a href="#"><li>YouTube Black Page</li></a>
</div>
</div>
</div>
<div class="dveloper-foot">
<h1>Black Page developed by : TM Motlhabeng</h1>
<p>&copy Black Page est 2017</p>
<div>
</footer>
<!-- hidden footer-->
<footer class="hidden-footer-login-hidden">
<img src="logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
<!--ending-->
</body>
</HTML>