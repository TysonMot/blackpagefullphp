<?php
session_start();
require ("php/function.php");

?>
<!DOCTYPE HTML>
<HTML>
<head>
<title>Black Page SA
</title>
<!--attachments-->
<link rel="stylesheet" type="text/css" href="css/layout.css"/>
<link rel="stylesheet" type="text/css" href="css/client-layout.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive-styles.css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap/css/bootstrap.css">
<link rel="shortcut icon" type="image/ico" href="logos/favicon.ico" />
<meta name="msvalidate.01" content="98301673E467740F111B0286A8ABB755" />
<!--endattachments-->
  <link rel="stylesheet" href="css/colorbox.css" type="text/css" />
<!-- java colorbox -->
<script src="js/jquery.colorbox.js"></script>
<script src="js/pop.js"></script>
<!-- java color close-->
</head>
<body class="body">
<heading class="main-heading" action="#" method="#">
<div class="search-box">
<form class="search-form">
<input type="text" name="search" placeholder="look for an item"></input>
<input type="submit" name="search-it" value="Search"></inptu>
</form>
</div>
<nav class="nav-bar">
<ul>
<li><a href="index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="#login" >Login</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
<!-- hidden div-->
<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="index.php">Home</a></li>

<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="php/user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="php/login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
<!-- close hidden-->
<!-- pop up login -->
<div class="pop-me-up-login" id="login">
<div class="login-outer">
<div class="login-heading">
<p class="login-exit"><a href="#">X</a></p>
</div>
<div class="login-form-details">
<form class="login-form" action="php/process.php" method="post">
<h1>Please provide your details</h1>
<input type="email" placeholder="Email" name="email" required autofocus></input>
<input type="password" placeholder="Password" name="password" required></input>
<input type="submit" name="login" value="Login"></input>
<footer class="footer-login">
<p>Click here to <a href="php/recover-password.php">retrive</a> password or <a href="#apply">register</a></p>
<p class="login-pra-foot">Black Page is here to promote/advertise your business, allow you to sell or buy products online</p>
</footer>
</form>
</div>
</div>
</div>
<!--apply pop up-->
<div class="pop-me-up" id="apply">
<div class="cover-outer">
<div class="pop-me-up-headings">
<img src="logos/Capture.png" alt="Black-page-logo" class="pop-up-logo">
<p class="pop-me-up-close"><a href="#">X</a></p>
</div>
<div class="cover">

<div class="application-fomr">
<h1>Application for advertising</h1>
<p>Please fill the form below to have your business listed on our Black Page</p>
<form class="black-page-form" action="php/reg.php" method="post" enctype="multipart/form-data">
<div class="form-person-details">
<h1>Person details</h1>
<input type="text" placeholder="Name" name="name" required autofocus></input>
<input type="text" placeholder="Surname" name="surname" required></input>
<input type="email" placeholder="Email" name="email" required></input>
<input type="tel" placeholder="Phone" name="tel" required></input>
<input type="text" placeholder="Address" name="address" required></input>
<select required name="province">
<option value="">Choose Province</option>
                         <option value="Limpopo">Limpopo</option>
                         <option value="Gauteng">Gauteng</option>
                         <option value="North West">North West</option>
                         <option value="Mpumalanga">Mpumalanga</option>
                         <option value="Western Cape">Western Cape</option>
                         <option value="KwaZulu-Natal">KwaZulu Natal</option>
                         <option value="Eastern Cape">Eastrn Cape</option>
                         <option value="Northern Cape">Northern Cape</option>
                         <option value="Free State">Free State</option>
                        
</select>
</div>
<div class="business-details">
<h1>Business details</h1>
<input type="text" placeholder="Name" name="name_busi" required></input>
<input type="email" placeholder="Email" name="email_busi" required></input>
<input type="tel" placeholder="Phone" name="tel_busi" required></input>
<input type="text" placeholder="Address" name="address_busi" required></input>
<input type="hidden" value='default.jpg' name="default"></input>
<select required name="busi_type">
<option value="">Choose business type</option>
                         <option value="Services Business">Services Business</option>
                         <option value="Merchandising Business">Merchandising Business</option>
                         <option value="Manufacturing Business">Manufacturing Business</option>
                         <option value="Hybrid Business">Hybrid Business</option>
                        
</select>
<textarea col="4" row="6" placeholder="Describ your business in short" name="busin_descrip" required></textarea>
</div>
<div class="files">
<h1>Product image</h1>
<input type="file" name="image"></input>
</div>
<div class="terms-of-use">
<p>By clicking send you agree to our Terms and Conditions of Black Page.</p>
</div>
<div class="submit-form">
<input type="submit" value="Send" name="upload"></input>
<input type="reset" value="Clear"></input>
</div>
</form>
</div>
</div>
</div>
</div>
<!--close-->
</heading>
<div class="banner">
<div class="welcome-text">
<article>
<header class="first-header-banner">
<h1>Welcome to Black Page</h1>
</header>
<footer class="first-banner-footer">
<p class="footer-banner-pra">Black Page was established by a group of youth who identified the need in advertising of small, medium and large businesses. We have realized that our brothers , sisters especially youth, won't be able to have their businesses advertised on radios, newspapers and TV due to lack of fund. Black Page has been established to bridge the gap between small, medium, and large businesses in the advertising industry. Below is the list of products we have on our Black Page</p> 
</footer>
<content>
<ul>
<li>Job alert</ll>
<li>business products advertising</ll>
<li>business recruitment</ll>
<li>day by day advertising</ll>
</ul>
</content>
</article>
</div>
</div>
<div class="container">
<div class="Contents-container">

<div class="clients-details">
<div class="catogories">
<h1>Black Page</h1>
<p class="clients-prah">Our advertising Black Page site focuses on advertising three main business</p>
<div class="buis-catogory">
<h1>Services Business</h1>
<footer class="clint-pra-foot">
<p>A service type of business provides intangible products. Service type firms offer professional skills, expertis, advice, and other smilar products.</p>
</footer>
<p>Example of Service businesses are:</p>
<ul>
<li>Schools</li>
<li>Repair shops</li>
<li>Hair salons</li>
<li>Banks</li>
<li>Accounting firms</li>
</div>
<div class="buis-catogory">
<h1>Merchandising Business</h1>
<footer class="clint-pra-foot">
<p>This type of business buys products at wholesale price and sells the same at retail price. They are known as "buy and sell businesses"
</footer>
<p>Examples of Merchandising business</p>
<ul>
<li>Grocery stores</li>
<li>Convenience stores</li>
<li>Distributors</li>
<li>Other resellers</li>
</div>
<div class="buis-catogory">
<h1>Manufacturing Business</h1>
<p>Manufacturing business buys products with the intention of using them as amterials in amking a new products.
</div>
<div class="buis-cat-photo">
<img src="board/marketing-manager-black-page.jpg" alt="black-page">
<h3>Mr Chokoe K</h3><br>
<h4>chokoe-md@black-page.co.za</h4>
<p class="contact-cat">+277 8724 0712<br>For advertising on black page please contact Mr Chokoe</p>
</div>
</div>
<!-- ad view-->
<div class="clients-cat-adv">


<?php 
$query_rotate = mysqli_query($con,"SELECT * FROM registrations WHERE active = 'YES'");
$selected = mysqli_num_rows($query_rotate);
if($selected > 0){
while($row_select=mysqli_fetch_array($query_rotate)){
  echo '<div class="slider-images-hidden-results">';
    echo '<div class="View-button">';
    echo '<div class="profile_pic_pic">';
    echo "<img src='images/".$row_select['profile_image']."'>";
    echo '</div>';
    echo '<div class="other-pra">';
      echo '<a href="add-pop-up-window.php?id='.$row_select['email_busi'].'"><p class="view-me">View</p></a>';
      echo '<h1>'.$row_select['name_busi'].'</h1>';
      echo '<p>'.$row_select['busi_descrip'].'</p>';
      echo '<hr class="line-black-pag">';
    echo '</div>';
    echo '</div>';
  echo "<img src='images/".$row_select['image_name']."'>";
    echo '<div class="slider-pra-cont">';
  echo '<h2>'.$row_select['busi_type'].'</h2>';
  echo '<p class="advert-text-wrap"><br>Black Page<br>"Your business publication, is our concern"<br>Advertise your business with Us</p>';
  echo '</div>';
  echo '</div>';
}
}else{
  echo '<p class="No-advert">No advert</p>';
}

?>


<?php
$query = mysqli_query($con,"SELECT * FROM registrations WHERE active = 'YES'");
$num = mysqli_num_rows($query);

   if ($num > 0){ 
while($ROW = mysqli_fetch_array($query)){
   $value = $ROW['email_busi'];
   $_SESSION["advert_id"] = $ROW['email_busi'];
   echo '<div class="results">';
   echo '<a class="iframe" href="add-pop-up-window.php?id='.$value.'"><p class="hide-class">'.$ROW['name_busi'].' <br>View </a>';
    echo '<div class="hidden-div">';
   echo '<p class="hidden-class-name">'.$ROW['name_busi'].'</p>';
   echo '<p class="hidden-class">'.$ROW['busi_type'].'</p>';
      echo '<p class="hidden-class">+27'.$ROW['phone_busi'].'</p>';
         echo '<p class="hidden-class">'.$ROW['address_busi'].'</p>';
            echo '<p class="hidden-class">R'.$ROW['item_price'].'-00</p>';
            echo '<a href="add-pop-up-window.php?id='.$value.'"><p class="hidden-button">View</p></a>';
   echo '</div>';
    echo "<img src='images/".$ROW['image_name']."'>";
echo '</div>';
} 
}else{
  echo '<p class="No-advert">No advert</p>';
}
?>
</div>

<!-- close add view-->
</div>

</div>
</div>
<!--pop-view-add-->




<!--close-->
<!--footer main -->
<footer class="main-footer">
<div class="main-footer-details">
<div class="foot-details">
<h1>Black Page</h1>
<p class="black-foot">We pledge to work with all kind of business and do our out most best to promote small businesses, regardless of their business history or experience<br>Black Page is a product of The Computer Xperts(PTY)LTD trading name BLACK PAGE SA</p>
<h2>Vision</h2>
<p class="black-float">Our vision is to see our Black Page being recognized as one of the best online advertising for all sort of businesses</p>
<h2>Mission</h2>
<p class="black-float">Our mission is to have all Small, Medium and Large business get an opportunity to have their businesses advertised Online at a small rate per month</p>
</div>
<div class="foot-details">
<h1>Black Page Service</h1>
<img src="logos/Capture.png" alt="Black-page-logo" class="pop-up-logo-footer">
<P class="black-page-foot-serv">The list below outline the Services/Products we offer</p>
<ul>
<li>Business Advertising</li>
<li>Business Promotion</li>
<li>Buy or Sell</li>
<li>Services Business</li>
<li>Merchandising Business</li>
<li>Manufacturing Business</li>
</ul>
<p class="black-page-foot-derv">Click <a href="#apply">here</a> to have your business listed on our page</p>
</div>
<div class="foot-details">
<h1>Other Services</h1>
<ul>
<li>Website desing</li>
<li>Systems development</li>
<li>Computer repairs</li>
<li>Graphic designs</li>
<li>Computer diagnosis</li>
<li>Office equipment</li>
<li>Networking</li>
<li>CCTV installation</li>
</ul>
<p>Contact person : TM Motlhabeng<br>Email:infor@thecomputerxperts.co.za<br>Cell:0785498402<br>www.thecomputerxperts.co.za</p>
</div>
<div class="foot-details">
<h1>Social Media</h1>
<div class="footer-social-med">
<ul class="social-media">
<a href="http://www.facebook.com/blackpageSA"><li>Facebook Black Page</li></a>
<a href="http://www.instagram.com/blackpageSA"><li>Instagram Black Page</li></a>
<a href="http://www.twitter.com/blackpageSA"><li>Twitter Black Page</li></a>
<a href="#"><li>YouTube Black Page</li></a>
</div>
</div>
</div>
<div class="dveloper-foot">
<h1>Black Page developed by : TM Motlhabeng</h1>
<p>&copy Black Page est 2017</p>
<div>
</footer>
<!-- hidden footer-->
<footer class="hidden-footer-login-hidden">
<img src="logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
<!--ending-->

</body>
</html>