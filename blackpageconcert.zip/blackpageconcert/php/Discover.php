<?php
session_start();
require ("function.php");
?>
<!DOCTYPE html>
<html>
<head>
<title>Black Page SA</title>
<link rel="stylesheet" type="text/css" href="../css/responsive-styles.css"/>
<link rel="stylesheet" type="text/css" href="../css/layout.css"/>
<link rel="stylesheet" type="text/css" href="../css/discover.css"/>
<link rel="stylesheet" type="text/css" href="../css/hidden-pages.css"/>
</head>
<body class="body">
<!-- head-->
<heading class="main-heading">

<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="../home.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="../contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
<!-- hidden div-->

</heading>
<div class="container">
<div class="dic-selection">
<?php
$q = mysqli_query($con,"SELECT * FROM registrations WHERE active = 'YES'");
$r = mysqli_num_rows($q);

if($r > 0 ){
	while($row = mysqli_fetch_array($q)){
		$image = $row['image_name'];
		echo '<div class="images-cont">';
		echo '<a href="#pop-image?id='.$row['email_busi'].'">';
		echo "<img src='../images/".$row['image_name']."'>";
		echo '</a>';
		echo '</div>';
	}
}


?>
<div class="pop-image-disc" id="images-cont">

</div>
</div>
</div>
<footer class="hidden-footer-login">
<img src="../logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
</body>
</html>