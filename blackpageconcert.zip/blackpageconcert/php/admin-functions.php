<?php
require("connect.php");

function getAdminDetails($unique_id){
	$array = array();
	$q = mysqli_query($con,"SELECT * FROM admin WHERE unique_number = '$unique'");
	while($row = mysqli_fetch_array($q)){
		$array = $row['email'];
		$array = $row['unique_number'];
	}
	return $array;
}

?>