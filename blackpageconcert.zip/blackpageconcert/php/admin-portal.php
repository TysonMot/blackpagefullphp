<?php
session_start();
require("admin-functions.php");
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="refresh" content="100">
<link rel="stylesheet" type"text/css" href="../css/admin-styles.css"/>
</head>
<body class="body">
     <?php
if(isset($_SESSION['unique_id']))
{
 
 ?>
</body>
<heading class="main-heading">
<nav class="nav-admin">
<ul>

<li><a href="session-admin.php">Log-out</a></li>
</nav>
</heading>
<div class="container">
<div class="update-big-banner">
<h4>Select a weekly banner</h4>
<form class="update-banner" action="weekly-banner.php" method="post">
				<select name="update-banner">
<?php 
$q_banner = mysqli_query($con,"SELECT * FROM registrations WHERE active ='YES'");
$g_banner = mysqli_num_rows($q_banner);
if($g_banner){
	while($r_banner = mysqli_fetch_array($q_banner)){
		echo '<option value='.$r_banner['email'].'>'.$r_banner['email'].'</option>';
	}
	echo '<input type="submit" name="banner-it" value="Update banner"></input>';
}
?>
</select>
</form>
</div>
 <div class="report-users">
<h1>Daily Report</h1>
<?php
//active queries//
$query = mysqli_query($con,"SELECT COUNT(*) AS active_users FROM registrations WHERE active = 'YES'");
$q = mysqli_num_rows($query);
$count = mysqli_fetch_array($query);
// in active users//
$query_inactive = mysqli_query($con,"SELECT COUNT(*) AS active_users FROM registrations WHERE active = 'NO'");
$q_inactive = mysqli_num_rows($query_inactive);
$count_inactive = mysqli_fetch_array($query_inactive);
// ending inactive users//
$query_reg = mysqli_query($con,"SELECT COUNT(*) AS active_users FROM registrations");
$q_reg = mysqli_num_rows($query_reg);
$count_reg = mysqli_fetch_array($query_reg);
//ending reg//
echo '<p class="active-u-reg">Registered user(s): '.$count_reg['active_users'].'</p>';
echo '<p class="active-u">Active user(s): '.$count['active_users'].'</p>';
echo '<p class="active-u-inactive">Pending user(s): '.$count_inactive['active_users'].'</p>';
?>
</div>
<div class="users-details">
<p class="hi-admin">Hi <?php echo $_SESSION['unique_id'];?></p>
<h1>Available users</h1>
<?php
$query = mysqli_query($con,"SELECT * FROM registrations");
$q = mysqli_num_rows($query);
if($q > 0){
	while($row = mysqli_fetch_array($query)){
		$id = $row['email'];
		echo '<div class="contain-data-users">';
		echo '<p class="users-data">'.$row['name_busi'].'</p>';
		//delete users//
		echo '<form class="same-style" action="delete-users.php" method="post" enctype="multipart/form-data">';
		echo '<input type="hidden" value='.$id.' name="delete-user"></input>';
		echo '<input type="submit" value="Delete '.$row['name'].'" name="delete-it"></input>';
		echo '</form>';
		//ending//
		//update status//
		echo '<form class="same-style" action="update-status.php" method="post">';
		echo '<select name="status-selection">';
		echo '<option value"">'.$row['active'].'</option>';
		echo '<option value"YES">YES</option>';
		echo '<option value"NO">NO</option>';
		echo '<input type="hidden" value='.$row['email'].' name="update-user"></input>';
		echo '<input type="submit" value="Update '.$row['name'].'" name="update-it"></input>';
		echo '</form>';
		//ending//
		//changing password
		
		echo '<form class="same-style" action="change-password.php" method="post">';
		echo '<input type="hidden" value='.$row['email'].' name="update-password-user"></input>';
		echo '<input type="hidden" value='.$row['email_busi'].' name="update-password-user-busi-email"></input>';
		if($row['password'] == ""){
			echo '<input type="text" placeholder="Set new password" name="update-password-user-new"></input>';
		}else
			echo '<input type="text" value='.$row['password'].' name="update-password-user-new"></input>';
		echo '<input type="submit" value="Update password" name="update-password-it"></input>';
		echo '</form>';
		//ending
		//sent a message to user//
		echo '<form class="same-style" action="admin-sent-text.php" method="post">';
		echo '<input type="hidden" value='.$row['email_busi'].' name="message-user-id"></input>';
echo '<input type="hidden" value='.$row['email'].' name="email"></input>';
		echo '<textarea col="20" row="50" placeholder="Type a message" name="admin-text" required></textarea>';
		echo '<input type="submit" value="Send" name="message-it"></input>';
		echo '</form>';
		//ending
		echo '</div>';
	}
}else{
	echo '<p class="No-data">No available users</p>';
}

?>
</div>


</div>
 <?php  
}else{
	echo '<div class="error-login">';
	echo '<h1>You have to login first</h1>';
	echo '<p>Click <a href="login-admin.php">HERE</a> to login</p>';
	echo '</div>';
}
?> 
</body>
</html>