<?php
session_start();
require("connect.php");

if(isset($_POST['message-it'])){
	$id = $_POST['message-user-id'];
	$text = $_POST['admin-text'];
$email = $_POST[email];
	if(mysqli_query($con,"INSERT INTO messages(user_id,names_messages,emails_messages,text_message) VALUES('$id','Admin','admin@black-page.co.za','$text')")){
			echo "<script type='text/javascript'>alert('Successfully updated and message has been sent to the user'); window.location.href = 'admin-portal.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'admin-portal.php';</script>;";
	}
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "New Message";
$status = "Updates";
$message = "\nYou have recieved a text message from Black Page SA Admin \nclick http://www.black-page.co.za to login\n\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nType: $status \n$message";
$recipient = $email;
$subject = "Administrator";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
	mysqli_close($con);
}

?>