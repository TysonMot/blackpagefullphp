<?php
session_start();
require("connect.php");
$id = $_SESSION['user_id'];
if(isset($_POST['send-logo-head'])){
  $user_id = $_POST['user_id_new'];
  
    $target = "../images/".basename($_FILES['image']['name']);
        $image = $_FILES['image']['name'];
        $type = $_FILES['image']['type'];
        $size = $_FILES['image']['size'];
        
  if(mysqli_query($con,"UPDATE registrations SET profile_image = '$image' WHERE email = '$id'")){
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
        echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'user.php';</script>;";
    }else{
        echo "<script type='text/javascript'>alert('failed to update'); window.location.href = 'user.php';</script>;";
    }
    mysqli_close($con);
}
?>