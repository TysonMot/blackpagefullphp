<?php
session_start();
require("connect.php");

if(isset($_POST['update-password-it'])){
	$new_password = $_POST['update-password-user-new'];
	$id = $_POST['update-password-user'];


	//message//
	$busi_id = $_POST['update-password-user-busi-email'];
	$id_name = "Admin";
	$email_admin = "info@blackpage.co.za";
	$message = "Your password has been reset\n New password is : $new_password";

	//ending
	if(mysqli_query($con,"UPDATE registrations SET password = '$new_password' WHERE email = '$id'")){
		$q = mysqli_query($con,"INSERT INTO messages (user_id,names_messages,emails_messages,text_message) VALUES ('$busi_id','$id_name','$email_admin','$message')");
		echo "<script type='text/javascript'>alert('Successfully updated and message has been sent to the user'); window.location.href = 'admin-portal.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'admin-portal.php';</script>;";
	}
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "Admin";
$status = "Congrats";
$message = "\nCongratulations, you have successfully registered to Black Page SA online advertising. Below is your login details\n\n Email : $id\nPassword : $new_password\nclick http://www.black-page.co.za/php/login-mini-form.php to login your account\n\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nType: $status \n$message";
$recipient = $id;
$subject = "Admin Updates";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
	mysqli_close($con);
}
?>