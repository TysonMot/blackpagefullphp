<?php
session_start();
require ("connect.php");
$id = $_SESSION['user_id'];
if (isset($_POST['update_company'])){
	$phone_com = $_POST['phone_comp'];

	$descrip_com = $_POST['descrip_comp'];
	
        if (mysqli_query($con,"UPDATE registrations SET phone_busi = '$phone_com', busi_descrip = '$descrip_com' WHERE email = '$id'")){
        	echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'user.php';</script>;";
        }
        else{
           	echo "<script type='text/javascript'>alert('Failed to updated'); window.location.href = 'user.php';</script>;";
        }
           mysqli_close($con);
}
?>