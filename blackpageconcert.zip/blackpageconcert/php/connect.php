<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "black_page";

$con = new mysqli($servername, $username, $password,$dbname);

?>
