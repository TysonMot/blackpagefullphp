<?php
require("connect.php");
if(isset($_POST['send-contact'])){
$name = $_POST['name'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$tel = $_POST['tel'];
$message = $_POST['message'];
$province = $_POST['province'];
$type_enq = $_POST['type-enqury'];

//conditions
if($name == "" OR $surname == "" OR $email == "" OR $message == "" OR $province == "" OR $type_enq == ""){
echo "<script type='text/javascript'>alert('Successfully updated and message has been sent to the user'); window.location.href = '../contact.php';</script>;";
}else{
$comp = "BLACK PAGE SA\n";
$subject = "Contact form";
$status = "Enquiry";
$messages = "From : $name, $surname\nEmail : $email\nTel : $tel\nProvince : $province\nEnquiry : $type_enq\nMessage :\n$message\n\nRegards\nBlack Page SA Contact form";
$formcontent="$comp \nType: $status \n$messages";
$recipient = "info@black-page.co.za";
$subject = "Admin Updates";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
}
mysqli_close($con);
}
?>