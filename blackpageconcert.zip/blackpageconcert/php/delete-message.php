<?php
session_start();
require("connect.php");

if(isset($_POST['delete-post'])){
		$user_id = $_POST['current-messs-user'];
		$delete_id = $_POST['current-messs-user-id-sender'];
		$name_id = $_POST['current-messs-user-id-sender-name'];

	if(mysqli_query($con,"DELETE FROM messages WHERE user_id = '$user_id' AND emails_messages = '$delete_id' AND names_messages = '$name_id'")){
		echo "<script type='text/javascript'>alert('Message deleted'); window.location.href = 'user.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('failed, error in connection'); window.location.href = 'user.php';</script>;";
	}
	mysqli_close($con);
}
 ?>