<?php
session_start();
require("connect.php");
if(isset($_POST['delete-it'])){
	$delete_id = $_POST['delete-user'];

	if(mysqli_query($con,"DELETE FROM registrations WHERE email = '$delete_id'")){
		echo "<script type='text/javascript'>alert('Successfully deleted'); window.location.href = 'admin-portal.php';</script>;";
	}else
	{
		echo "<script type='text/javascript'>alert('failed to delete user'); window.location.href = 'admin-portal.php';</script>;";
	}
	mysqli_close($con);
}

?>