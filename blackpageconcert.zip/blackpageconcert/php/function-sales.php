<?php
require("connect.php");
function getSalesID($unique_id_sales){
	$array = array();
	global $con;
	$q = mysqli_query($con,"SELECT * FROM admin WHERE unique_number = '$unique_id_sales'");
	while($row = mysqli_fetch_assoc($q)){
		$array['name'] = $row['name'];
		$array['unique'] = $row['unique_number'];
	}
	return $array;
}
?>