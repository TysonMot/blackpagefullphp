<?php
session_start();
require("connect.php");
function getAdvertData($advert_id){
	$array = array();
	global $con;
	$q = mysqli_query($con,"SELECT * FROM registrations WHERE email_busi = '$advert_id'");
while($r = mysqli_fetch_assoc($q))
{
$array['email'] = $r['email'];
$array['email_busi'] = $r['email_busi'];
$array['name_busi'] = $r['name_busi'];
$array['busi_online_status'] = $r['online_status'];
$array['busi_descrip'] = $r['busi_descrip'];
$array['active'] = $r['active'];
$array['province'] = $r['province'];
$array['name_busi'] = $r['name_busi'];
$array['busi_type'] = $r['busi_type'];
$array['busi_address'] = $r['address_busi'];
$array['busi_phone'] = $r['phone_busi'];
$array['busi_image'] = $r['image_name'];
$array['item_price'] = $r['item_price'];
$array['item_second_price'] = $r['second_price'];
$array['profile_image'] = $r['profile_image'];
// conditions all conditions must go here declared by founder Tyson Noyahabo Motlhabeng//
if ($r['service1'] == "" or $r['service2'] == "" or $r['service3'] == "" or $r['service1_descrip'] == "" or $r['service2_descrip'] == "" or $r['service3_descrip'] == "") {
	$array['service_status1'] = "Not-Assigned";
	$array['service_status2'] = "Not-Assigned";
	$array['service_status3'] = "Not-Assigned";
	$array['service_d1'] = "";
	$array['service_d2'] = "";
	$array['service_d3'] = "";
}else{
	$array['service_status1'] = $r['service1'];
	$array['service_status2'] = $r['service2'];
	$array['service_status3'] = $r['service3'];
	$array['service_d1'] = $r['service1_descrip'];
	$array['service_d2'] = $r['service2_descrip'];
	$array['service_d3'] = $r['service3_descrip'];
}
//end conditions//
}
return $array;
}

?>