<?php
session_start();
require("connect.php");

if(isset($_POST['Quote-form'])){
$name = $_POST['quote-name'];
$email_sender = $_POST['quote-name-email'];
$email_receiver = $_POST['email'];
$options = $_POST['quote-select'];
$email_id = $_POST['quote-name-email-hidden'];


if($name == "" OR $email_sender == "" OR $options == ""){
echo "<script type='text/javascript'>alert('Please fill all the fields'); window.location.href = '../add-pop-up-window.php?id=$email_id';</script>;";
}else {
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "RQF";
$status = "RQF";
$message = "\nYou have recieved an RQF(REQUEST FOR QUOTATION) \nFrom : $name\nFor $options\nEmail : $email_sender\n\n$name is requesting for RQF for $options, please send them an email regarding the above RQF. Thank You\n\nclick http://www.black-page.co.za to login\n\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nType: $status \n$message";
$recipient = $email_receiver;
$subject = "RFQ Black Page SA";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
echo "<script type='text/javascript'>alert('RQF has been sent'); window.location.href = '../add-pop-up-window.php?id=$email_id';</script>;";
}
mysqli_close($con);
}
?>