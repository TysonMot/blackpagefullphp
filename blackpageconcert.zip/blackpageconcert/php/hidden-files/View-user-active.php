<?php
session_start();
include("../function-sales.php");
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="hidden-styles-views.css"/>
</head>
<body class="body">
<?php 
if(isset($_SESSION['unique_id_sales']))
{
$usersDataSales = getSalesID($_SESSION['unique_id_sales']);
 ?>
<div class="container">
<div class="cont-id">
<h1><a href="../only-userarea.php">BACK</a></h1>
</div>
<div class="all-users">
<h2>Active Users</h2>
<div class="view-id">
<?php
$q = mysqli_query($con,"SELECT * FROM registrations WHERE active = 'YES'");
$e = mysqli_num_rows($q);
if($e == true){
	while($row = mysqli_fetch_array($q)){
		echo '<p class="clients">'.$row['name_busi'].'</p>';
	}
}else{
	echo '<p>NO ACTIVE USERS</p>';
}

?>
</div>
</div>
</div>
 <?php  
}else{
  echo '<div class="error-login">';
  echo '<h1>You have to login first</h1>';
  echo '<p>Click <a href="hidden.black-page.php">HERE</a> to login</p>';
  echo '</div>';
}
?> 
</body>
</html>