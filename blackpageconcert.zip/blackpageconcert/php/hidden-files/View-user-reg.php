<?php
session_start();
include("../function-sales.php");
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="hidden-styles-views.css"/>
</head>
<body class="body">
<?php 
if(isset($_SESSION['unique_id_sales']))
{
$usersDataSales = getSalesID($_SESSION['unique_id_sales']);
 ?>
<div class="container">
<div class="cont-id">
<h1><a href="../only-userarea.php">BACK</a></h1>
</div>
<div class="reg-forms">
<div class="application-fomr">
<h1>Application for advertising</h1>
<p>Please fill the form below to have your business listed on our Black Page</p>
<form class="black-page-form" action="../reg-sales.php" method="post" enctype="multipart/form-data">
<div class="form-person-details">
<h1>Person details</h1>
<input type="text" placeholder="Name" name="name" required autofocus></input>
<input type="text" placeholder="Surname" name="surname" required></input>
<input type="email" placeholder="Email" name="email" required></input>
<input type="tel" placeholder="Phone" name="tel" required></input>
<input type="text" placeholder="Address" name="address" required></input>
<input type="hidden" value='default.jpg' name="default"></input>
<select required name="province">
<option value="">Choose Province</option>
                         <option value="Limpopo">Limpopo</option>
                         <option value="Gauteng">Gauteng</option>
                         <option value="North West">North West</option>
                         <option value="Mpumalanga">Mpumalanga</option>
                         <option value="Western Cape">Western Cape</option>
                         <option value="KwaZulu-Natal">KwaZulu Natal</option>
                         <option value="Eastern Cape">Eastrn Cape</option>
                         <option value="Northern Cape">Northern Cape</option>
                         <option value="Free State">Free State</option>
                        
</select>
</div>
<div class="business-details">
<h1>Business details</h1>
<input type="text" placeholder="Name" name="name_busi" required></input>
<input type="email" placeholder="Email" name="email_busi" required></input>
<input type="tel" placeholder="Phone" name="tel_busi" required></input>
<input type="text" placeholder="Address" name="address_busi" required></input>
<select required name="busi_type">
<option value="">Choose business type</option>
                         <option value="Services Business">Services Business</option>
                         <option value="Merchandising Business">Merchandising Business</option>
                         <option value="Manufacturing Business">Manufacturing Business</option>
                         <option value="Hybrid Business">Hybrid Business</option>
                        
</select>
<textarea col="4" row="6" placeholder="Describ your business in short" name="busin_descrip" required></textarea>
</div>
<div class="other-busi-details">
<h1>Business details conti'</h1>
<h2>Business service and description</h2>
<input type="text" placeholder="" name="service1" required></input>
<textarea col="4" row="6" placeholder="Describ your business service in short" name="busin_descrip_service1" required></textarea>
<h2>Business service and description</h2>
<input type="text" placeholder="" name="service2" required></input>
<textarea col="4" row="6" placeholder="Describ your business  service in short" name="busin_descrip_service2" required></textarea>
<h2>Business service and description</h2>
<input type="text" placeholder="" name="service3" required></input>
<textarea col="4" row="6" placeholder="Describ your business service in short" name="busin_descrip_service3" required></textarea>
<h2>Password</h2>
<input type="text" placeholder="" name="password" required></input>
<h2>Activate Account[Yes(ACTIVATE)/NO(PENDING)</h2>
<select name="active" required>
<option value="NO">Account Activation Status</option>
<option value="YES">YES</option>
<option value="NO">NO</option>
</select>
</div>
<div class="files">
<h1>Product image[business logo/buildings/offices]</h1>
<input type="file" name="image"></input>
</div>
<div class="terms-of-use">
<p>By clicking send you agree to our Terms and Conditions of Black Page.</p>
</div>
<div class="submit-form">
<input type="submit" value="Send" name="upload" id="i_submit"></input>
<input type="reset" value="Clear"></input>
</div>
</form>

</div>
</div>
<footer class="footer">
<p>BLACK PAGE SA &copyCOPYRIGHT</p>
</footer>
 <?php  
}else{
  echo '<div class="error-login">';
  echo '<h1>You have to login first</h1>';
  echo '<p>Click <a href="hidden.black-page.php">HERE</a> to login</p>';
  echo '</div>';
}
?> 
</body>
</html>