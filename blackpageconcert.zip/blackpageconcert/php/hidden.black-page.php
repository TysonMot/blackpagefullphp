<?php 
session_start()
?>
<!DOCTYPE html>
<html>
<head>
<title>Applications</title>
<link rel="stylesheet" type="text/css" href="../css/hidden-styles.css"/>
</haed>
<body class="body">
<div class"container">
<div class="center">
<form class="Login-user" action="process-hidden.php" method="POST">
<h1>Login</h1>
<input type="email" name="email" placeholder="Email" required></input>
<input type="text" name="unique_id" placeholder="User Code" required></input>
<input type="password" name="pass" placeholder="Password" required></input>
<input type="submit" name="sent-me" value="Proceed"></input>
</form>
</div>
</div>
<footer class="footer-hidden-users">
<div class="foot-user">
<img src="../logos/Capture.png" alt="black-page">
<p>Copyright &copy Black Page SA&reg</p>
</div>
</footer>
</body>
</html>