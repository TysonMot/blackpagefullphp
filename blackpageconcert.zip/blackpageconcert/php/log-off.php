<?php
session_start();
include("connect.php");
	$logger = $_SESSION["unique_id_sales"];
		session_unset();
		session_destroy();
		echo "<script type='text/javascript'>alert('successfully logged off'); window.location.href = 'hidden.black-page.php';</script>;";
		header('location:hidden.black-page.php');

?>
