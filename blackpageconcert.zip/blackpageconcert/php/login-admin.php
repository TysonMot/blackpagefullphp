<?php 
session_start()
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type"text/css" href="../css/admin-styles.css"/>
</head>
<body class="body">
<div class="container">
<div class="login-form">
<form class="admin-form" action="process-admin.php" method="post">
<h3>Fill the form below to login as Administrator</h3>
<input type="email" name="email" placeholder="Email" required></input>
<input type="text" name="unique_id" placeholder="Unique Code" required></input>
<input type="password" name="pass" placeholder="Password" required></input>
<input type="submit" name="send-form" value="login"></input>
<p class="pass-recover"><a href="#">Forgot password?</a></p>
</form>
</div>
</div>
</body>
</html>