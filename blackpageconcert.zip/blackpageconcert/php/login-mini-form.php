<!DOCTYPE HTML>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../css/responsive-styles.css"/>
<link rel="stylesheet" type="text/css" href="../css/layout.css"/>
<link rel="stylesheet" type="text/css" href="../css/hidden-pages.css"/>
</head>
<body class="body">
<heading class="main-heading">
<nav class="nav-bar">
<ul>
<li><a href="../index.php">Home</a></li>
<li><a href="../contact.php">Contact Us</a></li>
</ul>
</nav>
<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="../index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="../contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
<!-- hidden div-->

</heading>

<!-- close hidden-->
<div class="login-outer-hidden">

<div class="login-form-details-hidden">
<form class="login-form-hidden" action="process.php" method="post">
<h1>Please provide your details</h1>
<input type="email" placeholder="Email" name="email" required autofocus></input>
<input type="password" placeholder="Password" name="password" required></input><br>
<input type="submit" name="login" value="Login"></input>
<footer class="footer-login-hidden">
<p>Click here to <a href="recover-password.php">retrive</a> password or <a href="register-mini-form.php">register</a></p>
<p class="login-pra-foot-hidden">Black Page is here to promote/advertise your business, allow you to sell or buy products online</p>
</footer>
</form>
</div>
</div>
<footer class="hidden-footer-login-hidden">
<img src="../logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
</body>
</html>