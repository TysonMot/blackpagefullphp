<?php
session_start();
require("connect.php");
function getUsersData($user_id)
{
$array = array();
$q = mysqli_query($con,"SELECT * FROM messages WHERE user_id = '$user_id'");
while($r = mysqli_fetch_assoc($q)){
$array['email_message'] = $r['emails_messages'];
$array['name_message'] = $r['names_messages'];
$array['text_message'] = $r['text_message'];
}
}

?>