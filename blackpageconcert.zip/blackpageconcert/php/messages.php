<?php
session_start();
require("connect.php");
if(isset($_POST['message-submit'])){
	$name_message = $_POST['message-us'];
	$email_message = $_POST['message-email-us'];
	$text_message = $_POST['message-us-text'];
	$message_email_us_user = $_POST['message-email-us-user'];
//email
$email = $_POST['email'];
	
	if(mysqli_query($con,"INSERT INTO messages(user_id,names_messages,emails_messages,text_message) VALUES('$message_email_us_user','$name_message','$email_message','$text_message')")){
		echo "<script type='text/javascript'>alert('Message has been sent'); window.location.href = '../add-pop-up-window.php?id=$message_email_us_user';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('Failed to sent check network settings'); window.location.href = '../home.php';</script>;";
	}
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "New Message";
$status = "Enquiry";
$message = "\nYou have recieved a text message from : $name_message \n\nEmail : $email_message \nTo view your message please click http://www.black-page.co.za to login\n\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nType: $status \n$message";
$recipient = $email;
$subject = "Text message";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");        
	mysqli_close($con);
}
?>