<?php
require("connect.php");
$Message_status = "";
if(isset($_POST['upload'])){
        $nam = $_POST['name'];
        $surnam = $_POST['surname'];
        $emai = $_POST['email'];
        $phon = $_POST['tel'];
         $addre = $_POST['address'];
         $provi = $_POST['province'];
         ///business details//
        $name_bus = $_POST['name_busi'];
        $email_bus = $_POST['email_busi'];
        $phone_bus = $_POST['tel_busi'];
        $address_bus = $_POST['address_busi'];
        $busi_ty = $_POST['busi_type'];
        $busi_descr = $_POST['busin_descrip'];
        //images upload//
        $target = "../images/".basename($_FILES['image']['name']);
        $image = $_FILES['image']['name'];
        $type = $_FILES['image']['type'];
        $size = $_FILES['image']['size'];

        //function image
    
        //default//
        $default = $_POST['default'];
        $valid = mysqli_query($con,"SELECT * FROM registrations WHERE email = '$emai'");
        $row = mysqli_fetch_array($valid);

 if($nam == "" OR $surnam == "" OR $emai == "" OR $phon == "" OR $addre == "" OR $provi == "" OR $name_bus == "" OR $email_bus == "" OR $phone_bus == "" OR $address_bus == "" OR $busi_ty == "" OR $busi_descr == "" OR $image == ""){
           echo "<script type='text/javascript'>alert('Please fill all required fields'); window.location.href = 'register-mini-form.php';</script>;";
 }elseif ($row['email'] == true OR $row['email_bus'] == true){
          echo "<script type='text/javascript'>alert('User already registered, Please login'); window.location.href = 'login-mini-form.php';</script>;";
 }elseif(mysqli_query($con,"INSERT INTO registrations(name, surname, email, phone,address,province, name_busi, email_busi, phone_busi, address_busi, busi_type, busi_descrip, image_name,profile_image )VALUES('$nam','$surnam','$emai','$phon','$addre','$provi','$name_bus','$email_bus','$phone_bus','$address_bus','$busi_ty','$busi_descr','$image','$default')")){
        echo "<script type='text/javascript'>alert('Successfully registered'); window.location.href = '..index.php';</script>;";
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "New Registration";
$status = "Panding";
$black_email = "new-reg@black-page.co.za";
$message = "\nYou have successfully registered on BLACK PAGE SA, Your password will be send to you shortly\n\nRegistered email : $emai\nCompany Name : $name_bus\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nRegistration Status: $status \n$message";
$recipient = $emai;
$subject = "Registration";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!"); 
       
//email to admin black page
$company = $name_bus;
$subject = "New Registration";
$status = "Registered";
$black_email = "new-reg@black-page.co.za";
$message = "\nNew member has registered\n\nRegistered email : $emai\nCompany Name : $name_bus\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$company \nRegistration Status: $status \n$message";
$recipient = $black_email;
$subject = "Registration";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
       move_uploaded_file($_FILES['image']['tmp_name'], $target); 
        }
        else{
           echo "<script type='text/javascript'>alert('Error in connection'); window.location.href = 'register-mini-form.php';</script>;";
        }
       
mysqli_close($con);
}

?>