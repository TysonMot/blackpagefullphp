<?php
session_start();
include("function-sales.php")
?>
<!DOCTYPE html>
<html>
<head>
<title>Applications</title>
<link rel="stylesheet" type="text/css" href="../css/layout.css"/>
<link rel="stylesheet" type="text/css" href="../css/hidden-styles.css"/>
</head>
<body class="body">
<?php
if(isset($_SESSION['unique_id_sales']))
{
   
$usersDataSales = getSalesID($_SESSION['unique_id_sales']);
 ?>
<div class="container">
<h1>HI <?php echo $usersDataSales['name'] ;?></h1>
<div class="logoff">
<h2 class="offf-offf"><a href="log-off.php/">LOGOUT</a></h2>
</div>
<?php 
$r = mysqli_query($con,"SELECT COUNT(name_busi) AS total_users FROM registrations");
$r_a = mysqli_query($con,"SELECT COUNT(name_busi) AS total_active FROM registrations WHERE active = 'YES'");
$r_p = mysqli_query($con,"SELECT COUNT(name_busi) AS total_not_active FROM registrations WHERE active = 'NO'");
$row = mysqli_fetch_assoc($r);
$row_a = mysqli_fetch_assoc($r_a);
$row_p = mysqli_fetch_assoc($r_p);
?>
<div class="selections">
<a href="hidden-files/View-user.php"><p class="Selection">View all users</p></a>
<a href="hidden-files/View-user-active.php"><p class="Selection">View Active users</p></a>
<a href="hidden-files/View-user-pending.php"><p class="Selection">View Pending users</p></a>
<a href="hidden-files/View-user-reg.php"><p class="Selection">Register New user</p></a>
</div>
<div class="statestics">
<h1>Overrall</h1>
<p class="stats">Registered users..[<?php echo $row['total_users'];?>]</p>
<p class="stats">Active users..[<?php echo $row_a['total_active'];?>]</p>
<p class="stats">Pending users..[<?php echo $row_p['total_not_active'];?>]</p>
</div>
<hr class="line"></hr>
<footer class="sales-footer">
<img src="../logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017 , Sales System</p>
</footer>
 <?php  
}else{
  echo '<div class="error-login">';
  echo '<h1>You have to login first</h1>';
  echo '<p>Click <a href="hidden.black-page.php">HERE</a> to login</p>';
  echo '</div>';
}
?> 
</body>
</head>