<?php
require("connect.php");
if(isset($_POST['send-recover'])){
	$email = $_POST['email'];


	//conditions and selection
	$q = mysqli_query($con,"SELECT * FROM registrations WHERE email = '$email'");
$row = mysqli_num_rows($q);
	$e = mysqli_fetch_array($q);
	$pass = $e['password'];
	if($email == ""){
		echo "<script type='text/javascript'>alert('Please enter your email'); window.location.href = 'recover-password.php';</script>;";
	}elseif($e['email'] == false){
	echo "<script type='text/javascript'>alert('Email address does not match any of our registered emails'); window.location.href = 'recover-password.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('An email containing your PASSWORD has been sent to you'); window.location.href = 'recover-password.php';</script>;";
//email to users admin and registered user
$comp = "BLACK PAGE SA\n";
$subject = "Password";
$status = "Password recovery";
$message = "\nBelow is your PASSWORD as requested\nPassword : $pass\n\n\nRegards\nBlack Page SA\ninfo@black-page.co.za\nwww.black-page.co.za";
$formcontent="$comp \nType: $status \n$message";
$recipient = $email;
$subject = "Password recovery";
$mailheader = "";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
}
mysqli_close($con);
}

?>