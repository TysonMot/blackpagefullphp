<?php
session_start();
include("connect.php");
if(isset($_POST['send-form']))
{
	
 $email = $_POST['email'];
 $pass = $_POST['pass'];
 $unique_id = $_POST['unique_id'];
if($email == "" OR $pass == "" OR $unique_id == ""){
	echo "<script type='text/javascript'>alert('Please enter Email or Password or Unique No'); window.location.href = 'login-admin.php';</script>;";
}

$result = mysqli_query($con,"SELECT * FROM admin WHERE email = '$email' AND password = '$pass' AND unique_number = '$unique_id'");
$row  = mysqli_fetch_array($result);
if(is_array($row)) {
$_SESSION["admin_id"] = $row[email];
$_SESSION["password_id"] = $row[password];
$_SESSION["unique_id"] = $row[unique_number];
} else {
echo "<script type='text/javascript'>alert('You have entered wrong details'); window.location.href = 'login-admin.php';</script>;";

}
}
if(isset($_SESSION["unique_id"])) {
header("Location:admin-portal.php");
}
?>  