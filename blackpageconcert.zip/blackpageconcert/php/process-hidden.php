<?php
session_start();
include("connect.php");
if(isset($_POST['sent-me']))
{
	
 $email_sales = $_POST['email'];
 $pass_sales = $_POST['pass'];
 $unique_id_sales = $_POST['unique_id'];
if($email_sales == "" OR $pass_sales == "" OR $unique_id_sales == ""){
	echo "<script type='text/javascript'>alert('Please enter Email or Password or Unique No'); window.location.href = 'hidden.black-page.php';</script>;";
}

$result = mysqli_query($con,"SELECT * FROM admin WHERE email = '$email_sales' AND password = '$pass_sales' AND unique_number = '$unique_id_sales'");
$row  = mysqli_fetch_array($result);
if(is_array($row)) {
$_SESSION["admin_id_sales"] = $row[email];
$_SESSION["password_id_sales"] = $row[password];
$_SESSION["unique_id_sales"] = $row[unique_number];
} else {
echo "<script type='text/javascript'>alert('You have entered wrong details'); window.location.href = 'hidden.black-page.php';</script>;";

}
}
if(isset($_SESSION["unique_id_sales"])) {
header("Location:only-userarea.php");
}
?>  