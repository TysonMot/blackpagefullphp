<?php
session_start();
include("connect.php");
if(isset($_POST['login']))
{
	
 $email = $_POST['email'];
 $pass = $_POST['password'];
if($email == "" OR $pass == ""){
	echo "<script type='text/javascript'>alert('Please enter Email or Password'); window.location.href = '../#login';</script>;";
}

$result = mysqli_query($con,"SELECT * FROM registrations WHERE email = '$email' AND password = '$pass'");
$row  = mysqli_fetch_array($result);
if(is_array($row)) {
$_SESSION["user_id"] = $row[email];
$_SESSION["password_id"] = $row[password];
} else {
echo "<script type='text/javascript'>alert('You have entered wrong details'); window.location.href = '../#login';</script>;";

}
}
if(isset($_SESSION["user_id"])) {
header("Location:user.php");
}
?>  