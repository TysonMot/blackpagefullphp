<!DOCTYPE HTML>
<html>
<head>
<title>Black Page SA</title>
<link rel="stylesheet" type="text/css" href="../css/responsive-styles.css"/>
<link rel="stylesheet" type="text/css" href="../css/recover-pass.css"/>
<link rel="stylesheet" type="text/css" href="../css/layout.css"/>
 <link rel="shortcut icon" type="image/ico" href="../logos/favicon.ico" />
</head>
<body class="body">
<heading class="main-heading">

<nav class="nav-bar">
<ul>
<li><a href="../index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="user.php">Profile</a>';
     }else {
 echo '<a href="#login">Login</a>';
     }
?></li>
<li><a href="../contact.php">Contact Us</a></li>
</ul>
</nav>
<!-- hidden div-->
<div class="hidden-menu-new-nav">
<nav class="nav-bar-hidden">
<ul>
<li><a href="../index.php">Home</a></li>
<li><?php 
if (isset($_SESSION['user_id']))
{
    echo '<a href="user.php" class="profile_color">Profile</a>';

     }else {
 echo '<a href="login-mini-form.php" >Login</a>';
     }
?></li>
<li><a href="../contact.php">Contact Us</a></li>
</ul>
</nav>
</div>
</heading>
<div class="container-recover">
<div class="inner-pass">
<div class="form-pass">
<form class="form-recover" action="password.php" method="POST">
<h1>Password recovery</h1>
<p>Please fill in your email below</p>
<input type="email" name="email" placeholder="Email" required></input>
<input type="submit" value="Recover" name="send-recover">
</form>
</div>
</div>
</div>
<!--footer main -->
<footer class="main-footer">
<div class="main-footer-details">
<div class="foot-details">
<h1>Black Page</h1>
<p class="black-foot">We pledge to work with all kind of business and do our out most best to promote small businesses, regardless of their business history or experience<br>Black Page is a product of The Computer Xperts(PTY)LTD trading name BLACK PAGE SA</p>
<h2>Vision</h2>
<p class="black-float">Our vision is to see our Black Page being recognized as one of the best online advertising for all sort of businesses</p>
<h2>Mission</h2>
<p class="black-float">Our mission is to have all Small, Medium and Large business get an opportunity to have their businesses advertised Online at a small rate per month</p>
</div>
<div class="foot-details">
<h1>Black Page Service</h1>
<img src="../logos/Capture.png" alt="Black-page-logo" class="pop-up-logo-footer">
<P class="black-page-foot-serv">The list below outline the Services/Products we offer</p>
<ul>
<li>Business Advertising</li>
<li>Business Promotion</li>
<li>Buy or Sell</li>
<li>Services Business</li>
<li>Merchandising Business</li>
<li>Manufacturing Business</li>
</ul>
<p class="black-page-foot-derv">Click <a href="#">here</a> to have your business listed on our page</p>
</div>
<div class="foot-details">
<h1>Other Services</h1>
<ul>
<li>Website desing</li>
<li>Systems development</li>
<li>Computer repairs</li>
<li>Graphic designs</li>
<li>Computer diagnosis</li>
<li>Office equipment</li>
<li>Networking</li>
<li>CCTV installation</li>
</ul>
<p>Contact person : TM Motlhabeng<br>Email:infor@thecomputerxperts.co.za<br>Cell:0785498402<br>www.thecomputerxperts.co.za</p>
</div>
<div class="foot-details">
<h1>Social Media</h1>
<div class="footer-social-med">
<ul class="social-media">
<a href="http://www.facebook.com/blackpageSA"><li>Facebook Black Page</li></a>
<a href="http://www.instagram.com/blackpageSA"><li>Instagram Black Page</li></a>
<a href="http://www.twitter.com/blackpageSA"><li>Twitter Black Page</li></a>
<a href="#"><li>YouTube Black Page</li></a>
</div>
</div>
</div>
<div class="dveloper-foot">
<h1>Black Page developed by : TM Motlhabeng</h1>
<p>&copy Black Page est 2017</p>
<div>
</footer>
<!-- hidden footer-->
<footer class="hidden-footer-login-hidden">
<img src="../logos/Capture.png" alt="black-page">
<p class="hidden-footer-pra">Copyright &copy Black Page 2017</p>
</footer>
<!--ending-->
</body>
</html>