<?php
session_start();
include("connect.php");
	$logger = $_SESSION["unique_id"];
		session_unset();
		session_destroy();
		echo "<script type='text/javascript'>alert('successfully logged off'); window.location.href = 'login-admin.php';</script>;";
		header('location:login-admin.php');

?>
