<?php
session_start();
include("connect.php");
$online_statess = "Offline";

	$logger = $_SESSION["user_id"];
	$query = "UPDATE registrations SET online_status = '$online_statess' WHERE email = '$logger'";
	$results = mysqli_query($con,$query);

		session_unset();
		session_destroy();
		header('location:../index.php');

?>
