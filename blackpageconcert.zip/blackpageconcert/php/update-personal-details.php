<?php
session_start();
require("connect.php");
$id = $_SESSION['user_id'];
if(isset($_POST['update_personal'])){
	$name_update = $_POST['update_name'];
	$phone_update = $_POST['update_phone'];
	$address_update = $_POST['update_address'];
	$province_update = $_POST['update_province'];

	if(mysqli_query($con,"UPDATE registrations SET name = '$name_update', phone = '$phone_update', address = '$address_update', province = '$province_update' WHERE email = '$id'" )){
			echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'user.php';</script>;";
        }
        else{
           	echo "<script type='text/javascript'>alert('Failed to updated'); window.location.href = 'user.php';</script>;";
        }
        mysqli_close($con);
}
?>