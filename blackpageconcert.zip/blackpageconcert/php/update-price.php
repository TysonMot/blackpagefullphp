<?php
session_start();
require ("connect.php");
$id = $_SESSION['user_id'];
if (isset($_POST['submit_price'])){
	$price = $_POST['price'];
	$price_second = $_POST['price_second'];
if ($price == "" or $price < 1){
	echo "<script type='text/javascript'>alert('Please assign an amount and the amount cannot be less than 1'); window.location.href = 'user.php';</script>;";
	}elseif (mysqli_query($con,"UPDATE registrations SET item_price = '$price', second_price = '$price_second' WHERE email = '$id'")){
			echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'user.php';</script>;";
        }
        else{
           	echo "<script type='text/javascript'>alert('Failed to updated'); window.location.href = 'user.php';</script>;";
	}
	mysqli_close($con);
}
?>