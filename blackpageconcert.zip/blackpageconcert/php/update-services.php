<?php
session_start();
require("connect.php");
$id = $_SESSION['user_id'];
if(isset($_POST['update-services'])){
	$service1 = $_POST['service_1'];
	$service2 = $_POST['service_2'];
	$service3 = $_POST['service_3'];
	// descriptions
	$service1_d = $_POST['descrip_comp_update_1'];
	$service2_d = $_POST['descrip_comp_update_2'];
	$service3_d = $_POST['descrip_comp_update_3'];

	if ($service3 == "" or $service3 == "" or $service3 ==""){
		echo "<script type='text/javascript'>alert('Please fill all the required fields'); window.location.href = 'user.php';</script>;";
	}elseif (mysqli_query($con,"UPDATE registrations SET service1 = '$service1', service2 = '$service2', service3 = '$service3', service1_descrip ='$service1_d', service2_descrip = '$service2_d', service3_descrip = '$service3_d' WHERE email = '$id'")){
		echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'user.php';</script>;";
	}else {
		echo "<script type='text/javascript'>alert('Not updated updated'); window.location.href = 'user.php';</script>;";
	}
	mysqli_close($con);
}
?>