<?php
session_start();
require ("connect.php");
if(isset($_POST['update-it'])){
	$update_status = $_POST['update-user'];
	$update_selected = $_POST['status-selection'];

	if(mysqli_query($con,"UPDATE registrations SET active = '$update_selected' WHERE email = '$update_status'")){
			echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'admin-portal.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'admin-portal.php';</script>;";
	}
	mysqli_close($con);
}

?>