<?php
session_start();
require("function.php")
?>
<!DOCTYPE HTML>
<HTML>
<head>
<title>Black Page SA</title>
<!--attachments-->
<link rel="stylesheet" type="text/css" href="../css/layout.css"/>
<link rel="stylesheet" type="text/css" href="../css/dashboard.css"/>
<link rel="stylesheet" type="text/css" href="../css/responsive-styles.css"/>
<link rel="shortcut icon" type="image/ico" href="../logos/favicon.ico" />

<!--endattachments-->
</head>
<body class="body">
      <?php
if(isset($_SESSION['user_id']))
{
   
$usersData = getUsersData($_SESSION['user_id']);
 ?>

<header class="dashboard">
<?php 

?>
<nav class="dashboard-nav">
<p class="username-dash">Hi <?php echo $usersData['name'];?></p>
<ul class="link-dash">
<li><a href="../index.php">Home</a></li>
<?php 
$user_id_num = $usersData['busi_email'];
$count = mysqli_query($con,"SELECT user_id, COUNT(user_id) AS num_text FROM messages WHERE user_id = '$user_id_num'");
$num_text = mysqli_num_rows($count);



if($num_text > 0){
  if($row_text = mysqli_fetch_array($count)){
  echo '<li><a href="#inbox">Inbox('.$row_text['num_text'].')</a></li>';
}
}else
{
    echo '<li><a href="#inbox">No Messages</a></li>';
}
?>
<li><a href="session.php">Logout</a></li>
</ul>
</nav>

</header>

</div>
<!-- close hidden-->
<div class="dash-container">
<div class="dash-inner-container">
<p class="username-dash-side">Hi <?php echo $usersData['name'];?></p>
<h1 class="heading-dash">Dashboard</h1>

 <div class="prof_info">
 <h1>Profile details</h1>
 <p class="user-details">Names : <?php echo $usersData['name']."  ".$usersData['surname'];?></p>
 <p class="user-details">Email : <?php echo $usersData['email'];?></p>
 <p class="user-details">Phone : <?php echo "0".$usersData['phone'];?></p>
 <p class="user-details">Address : <?php echo $usersData['address'];?></p>
 <p class="user-details">Town : <?php echo $usersData['province'];?></p>
  <p class="user-details">Status : <?php echo $usersData['active'];?></p>
  <p class="user-details">Activation Status : <?php echo $usersData['status_message'];?></p>
  

  </div>

  <div class="dash-side">
  		<h1>Company details</h1>
  		<div class="busi_prof">
  		  <p class="user-details">Company name : <?php echo $usersData['name_busi'];?></p>
  <p class="user-details">Business type : <?php echo $usersData['busi_type'];?></p>
   <p class="user-details">Business address : <?php echo $usersData['busi_address'];?></p>
    <p class="user-details">Business phone : <?php echo "0".$usersData['busi_phone'];?></p>
     <p class="user-details">Business email : <?php echo $usersData['busi_email'];?></p>
      <p class="user-details">Business description : <?php echo $usersData['busi_descrip'];?></p>
      <h4>Compnay/Business Services</h4>
       <p class="user-details">- <?php echo $usersData['service_status1'];?><br> - Description<br> <?php echo $usersData['service_d1'];?></p>
        <p class="user-details">- <?php echo $usersData['service_status2'];?><br> - Description<br><?php echo $usersData['service_d2'];?></p>
         <p class="user-details">- <?php echo $usersData['service_status3'];?><br> - Description<br><?php echo $usersData['service_d3'];?></p>
         <p><a href="#details-services">Edit services</a></p>
      
      <div class="prices-form-data">
      <form class="item_price" action="update-price.php" method="POST" enctype="multipart/form-data">
        <h4>Assign amount for your products</h4>
        <input type="text" name="price" placeholder="First amount"></input>
        <input type="text" name="price_second" placeholder="Second amount"></input>
        <input type="submit" value="Price It" name="submit_price"></input>
        <p class="current-price">Current amount ranges<br>From <?php echo " R ".$usersData['item_price'];?> - <?php echo " R ".$usersData['item_second_price'];?></p>
      </form>
  </div>
  </div>
  <div class="busi_product_image">
  <h2>Product image</h2>
  <p class="busi_images"><a href="#pop-image"><?php echo "<img src='../images/".$usersData['busi_image']."'>";?></a></p>
  <form class="change-logo" action="change-logo.php" method="POST" enctype="multipart/form-data">
      <h3>Change Product image</h3>
      <input type="hidden" name="user_id_new" value=<?php echo $usersData['busi_email'];?></input>
      <input type="file" name="image" required></input>
      <input type="submit" name="send-logo" value="Change"></input>
  </form>
  
  <form class="change-logo" action="change-logo-head.php" method="POST" enctype="multipart/form-data">
        <p class="busi_images"><?php echo "<img src='../images/".$usersData['profile_image']."'>";?></p>
      <h3>Change compnay logo</h3>
       <input type="hidden" name="user_id_new" value=<?php echo $usersData['busi_email'];?></input>
      <input type="file" name="image" required></input>
      <input type="submit" name="send-logo-head" value="Change"></input>
  </form>
  </div>
  </div>
  <div class="dash-update-buttons">
  <ul>
<a href="#details-edit"><li>Edit details</li></a>
<a href="#details-image"><li>Edit company details</li></a>
</ul>
</div>
<div class="pop-user-image" id="pop-image">
<div class="outer-pop-image">
<div class="heading-pop-image">
<p class="user-pop-name"><?php echo $usersData['name'];?></p>
<p class="pop-close-it"><a href="#">X</a></p>
</div>
<div class="inner-pop-image">
 <p class="busi_images"><?php echo "<img src='../images/".$usersData['busi_image']."'>";?></p>
</div>
</div>
</div>
  </div>
  </div>
  <!--pop-up edits-->
  <div class="pop-up-edit-details" id="details-edit">
  <div class="outer-details-edit">
   <a href="#" class="pop-up-close-update-details">X</a>
  <div class="inner-details-edit">
  <form class="details-form" action="update-personal-details.php" method="post" enctype="multipart/form-data">
  <h1>Edit personal details</h1>
  <p>Email address and other fields cannot be updated!</p>
  <p>Edit details</p>
<input type="text" value=<?php echo $usersData['name'];?> name="update_name" required autofocus ></input>
<input type="tel" value=<?php echo "0".$usersData['phone'];?> name="update_phone" required></input>
<input type="text" value=<?php echo $usersData['address'];?> name="update_address" required></input>
<select required name="update_province">
<option value=""><?php echo $usersData['province'];?></option>
                         <option value="Limpopo">Limpopo</option>
                         <option value="Gauteng">Gauteng</option>
                         <option value="North West">North West</option>
                         <option value="Mpumalanga">Mpumalanga</option>
                         <option value="Western Cape">Western Cape</option>
                         <option value="KwaZulu-Natal">KwaZulu Natal</option>
                         <option value="Eastern Cape">Eastrn Cape</option>
                         <option value="Northern Cape">Northern Cape</option>
                         <option value="Free State">Free State</option>
                        
</select>
  <input type="submit" value="Update" name = "update_personal"></input>
   <input type="reset" value="Clear"></input>
  </form>

  </div>
  </div>
  </div>
  <!--pop up edit photo-->
  <div class="pop-up-edit-details" id="details-image">
  <div class="outer-details-edit">
   <a href="#" class="pop-up-close-update-details">X</a>
  <div class="inner-details-edit">
  <form class="details-form" action="company-update-details.php" method="post" enctype="multipart/form-data" >
  <h1>Business details</h1>
  <p>Company/Business name and other fields cannot be edited.</p>
<input type="text" placeholder="Name" name="phone_comp" value=<?php echo"0". $usersData['busi_phone'];?> required></input>
<textarea col="4" row="6" placeholder="Describ your business in short" name="descrip_comp" required></textarea>
  <input type="submit" value="Update" name = "update_company"></input>
   <input type="reset" value="Clear"></input>
</div>
  </form>
  </div>
  </div>
  </div>
  <!--close-->
<!-- pop up edit services-->
  <div class="pop-up-edit-details" id="details-services">
  <div class="outer-details-edit">
   <a href="#" class="pop-up-close-update-details">X</a>
  <div class="inner-details-edit-services">
  <h2>Compnay/Business Services</h2>
      <form class="update-services-form" action="update-services.php" method="POST" enctype="multipart/form-data">
      <p>Service 1</p>
      <input type="text" value=<?php echo $usersData['service_status1'];?> name="service_1" required></input>
     <textarea col="4" row="6" placeholder="Service 1 description" name="descrip_comp_update_1" required></textarea>
     <p>Service 2</p>
      <input type="text" value=<?php echo $usersData['service_status2'];?> name="service_2" required></input>
      <textarea col="4" row="6" placeholder="Service 2 description" name="descrip_comp_update_2" required></textarea>
      <p>Service 3</p>
      <input type="text" value=<?php echo $usersData['service_status3'];?> name="service_3" required></input>
      <textarea col="4" row="6" placeholder="Service 3 description" name="descrip_comp_update_3" required></textarea>
      <input type="submit" name="update-services" value="update"></input>
      </form>
      </div>
  </div>

  </div>
  <!--close-->
  <!-- pop up inbox-->
 <div class="pop-up-edit-details-messages" id="inbox">
  <div class="outer-details-edit-messages">
   <a href="#" class="pop-up-close-update-details">X</a>
  <div class="inner-details-edit-messages">
  <!-- loop for messages-->
  <?php
  $user_id = $usersData['busi_email'];
$query = "SELECT * FROM messages WHERE user_id = '$user_id'";
$result = mysqli_query($con,$query);
$num = mysqli_num_rows($result);
echo '<div class="message-container-div">';
   if ($num > 0){ 
while($ROW = mysqli_fetch_array($result)){
  $delete_id = $ROW['emails_messages'];
  $name_id = $ROW['names_messages'];
     echo '<div class="messages">';
   echo '<h1 class="details-pra-driv">'.$ROW['names_messages'].'</h1>'; 
   echo '<h4> '.$ROW['emails_messages'].'</h4>';
   echo '<p class="messages-pra-details"> '.$ROW['text_message'].'</p>';
   echo '<form class="form-delete-message" action="delete-message.php" method="post" enctype="multipart/form-data" >';
echo '<input type="hidden" name="current-messs-user" value ='.$usersData['busi_email'].'></input>';
echo '<input type="hidden" name="current-messs-user-id-sender" value ='.$delete_id.'></input>';
echo '<input type="hidden" name="current-messs-user-id-sender-name" value ='.$name_id.'></input>';
echo '<input type="submit" name="delete-post" value="Delete"></input>';
echo '</form>';
   echo '</div>';
}
} else {
  echo "You have no messages";
}
echo '</div>';

?>
  <!-- loops mix it poi-->

       </div>
  </div>
  </div>

  <!-- close pop up inbox-->

<footer class="dash-footer-user-main">
<div class="developer-dash">
<img src="../logos/Capture.png" alt="black page"/>
<h2>Technical Support</h2>
<p class="techinical-support">For any techinical problems, please contact us on<br>Email: technical@blackpage.co.za<br>Cell: 0786498402</p>
</div>
<div class="developer-dash">
<h2>Developer</h2>
<p class="deve-details">TM Motlhabeng<br>Webinar and Software developer</br>Email: tmmotlhabeng@thecomputerxperts.co.za</p>
</div>
<div class="developer-dash">
<h2>Account details</h2>
<p class="deve-details">Bank Name: First National Bank(FNB)<br>Account type: Cheque<br>Account holder : The Computer Xperts(PTY)LTD<br>Account Number : 6269 1460 332<br><br>NB: When making payments make use of your business name as Reference</p>
</div>
<div class="last-footer-dash">
<p>&copy BlACK PAGE EST 2017</p>
</div>
</footer>
 <?php  
}else{
  echo '<div class="error-login">';
  echo '<h1>You have to login first</h1>';
  echo '<p>Click <a href="login-mini-form.php">HERE</a> to login</p>';
  echo '</div>';
}
?> 
</body>
</HTML>

<!---->