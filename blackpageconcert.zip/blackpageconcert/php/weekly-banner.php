<?php
session_start();
require("connect.php");

if(isset($_POST['banner-it'])){
	$banner = $_POST['update-banner'];

	if(mysqli_query($con,"UPDATE weekly_banner SET email = '$banner'")){
		echo "<script type='text/javascript'>alert('Successfully updated'); window.location.href = 'admin-portal.php';</script>;";
	}else{
		echo "<script type='text/javascript'>alert('Successfully deleted'); window.location.href = 'admin-portal.php';</script>;";
	}
	mysqli_close($con);
}
?>